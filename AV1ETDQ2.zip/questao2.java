import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class questao2{

    public static void main(String[] args) throws FileNotFoundException {

        Queue<String> fila_deputados = new LinkedList<>();

        Scanner ler = new Scanner(new File("deputadosfederais.txt"));
        while (ler.hasNextLine()){
            fila_deputados.add(ler.nextLine());
       }

        for (int i=0; i < 20; i++){
            System.out.println("***Fileira 1*** : " + fila_deputados.poll());
        }
        System.out.println("\n\n-----------------------------------------------------\n");
        for (int i=20; i < 40; i++){
            System.out.println("***Fileira 2*** : " + fila_deputados.poll());
        }
        System.out.println("\n\n-----------------------------------------------------\n");
        for (int i=40; i < 53; i++){
            System.out.println("***Fileira 3*** : " + fila_deputados.poll());
        }
    }
}